# This AWS account's SCP only allows ap-southeast-2 (us-east-1 is denied)
aws_region = "ap-southeast-2"

# Free-plan account: only Free Tier eligible instance types can be launched (t3.medium is rejected)
cpu_instance_type = "m7i-flex.large"
